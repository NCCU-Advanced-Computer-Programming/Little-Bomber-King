﻿using Bomb.Src.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Bomb.Src.Scene
{
    class Box : Image
    {
        public bool canDestroy { get; set; }
        public bool canKick { get; set; }
        public Box(bool canDestroy,bool canKick)
            : base()
        {
            this.canDestroy = canDestroy;
            this.canKick = canKick;
        }
        public void onKick(WalkDirection dir)
        {
            
        }
        public void onDestroy()
        {
            
        }
    }

}
