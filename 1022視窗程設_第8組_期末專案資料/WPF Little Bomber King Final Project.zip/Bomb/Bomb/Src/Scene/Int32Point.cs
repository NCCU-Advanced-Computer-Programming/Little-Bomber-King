﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomb.Src.Scene
{
    class Int32Point
    {
        
        public int x { get; set; }
        public int y { get; set; }
        public Int32Point()
        {
 
        }
        public Int32Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public override bool Equals(object obj)
        {
            Int32Point that = obj as Int32Point;
            return this.x == that.x && this.y == that.y;
        }
        
    }
}
