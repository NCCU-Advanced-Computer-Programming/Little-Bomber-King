﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomb.Src.Tile
{
    class TileProperty
    {
        public string canKick { get; set; }
        public string canDestroy { get; set; }
    }
}
